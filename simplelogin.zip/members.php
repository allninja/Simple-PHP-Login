<?php

function logged()
{
	//Connects to your Database 

	mysql_connect("localhost", "sitkaotw_bb", "E2f~jnDmYm7C") or die(mysql_error()); 
	mysql_select_db("sitkaotw_battlecards") or die(mysql_error()); 

 //checks cookies to make sure they are logged in 
 if(isset($_COOKIE['ID_your_site'])){ 

 	$username = $_COOKIE['ID_your_site']; 
 	$pass = $_COOKIE['Key_your_site']; 
 	$check = mysql_query("SELECT * FROM users WHERE username = '$username'")or die(mysql_error()); 

 	while($info = mysql_fetch_array( $check )){ 

		//if the cookie has the wrong password, they are taken to the login page 
 		if ($pass != $info['password']){
			return 0;
 		}
		//otherwise they are shown the admin area
		else{
		
		return 1;
 		}
	}
}

 else
 { //if the cookie does not exist, they are taken to the login screen 
		return 0;
 }
 
}

if(logged() == 1)
{
	 echo "<a href=logout.php>Logout</a>"; 
	
}
else
{
	 header("Location: login.php"); 
	
}
     
 ?>
