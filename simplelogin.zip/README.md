Simple-PHP-Login
================

By: Angela Bradley

A very simple PHP script with MySQL backend to store usernames, passwords, and use cookies to protect a member's area.

All code is as-is. No support provided.

Do with it what you will... happy coding! :)
